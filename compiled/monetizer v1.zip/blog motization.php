<?php
/*
Plugin Name: Blog Monitization
Plugin URI: https://mrteey.com
Description: Blog Monitization Plug, Allows View of Single Post only by registred users.
Author: Mr.Teey
Version: 2.1
Author URI: https://mrteey.com
License: GPL2
*/


// When plugin is activated
function prepare_plugin() {

	$thanks = get_page_by_path( 'thanks' );
	$paid = get_page_by_path( 'paid' );
	$upgrade = get_page_by_path( 'upgrade' );

	// check if thanks page exists:
		if (empty($thanks)){
			// Create the page object
			$page = array(
				'post_type'     => 'page',
				'post_title'    => 'Thanks',
				'post_content'  => 'Thank you for your payment!.',
				'post_status'   => 'publish',
				'post_author'   => 1
			);
			
			// Insert the post into the database
			wp_insert_post( $page );
		}
	// check if paid page exists:
		if (empty($paid)){
			// Create the page object
			$page = array(
				'post_type'     => 'page',
				'post_title'    => 'Paid',
				'post_content'  => 'Thank you for your payment!.',
				'post_status'   => 'publish',
				'post_author'   => 1
			);
			
			// Insert the post into the database
			wp_insert_post( $page );
		}
	// check if upgrade page exists:
		if (empty($upgrade)){
			// Create the page object
			$page = array(
				'post_type'     => 'page',
				'post_title'    => 'Upgrade',
				'post_content'  => 'You have to upgrade your plan to view this page <button><a href="/plans" style="color:white">UPGRADE</a></button>',
				'post_status'   => 'publish',
				'post_author'   => 1
			);
			
			// Insert the post into the database
			wp_insert_post( $page );
		}

	do_action( 'prepare_plugin' );
}
register_activation_hook( __FILE__, 'prepare_plugin' );

//Remove Admin Bar Except for Administrator

// add_action('after_setup_theme', 'remove_admin_bar');
 
// function remove_admin_bar() {
// if (!current_user_can('administrator') && !is_admin()) {
//   show_admin_bar(false);
// }
// }


//Redirect from Single post if not logged in
 
add_action( 'template_redirect', 'redirect_from_post' );

function redirect_from_post() {

if ( is_single() and !is_admin()) {
	//user is logged in
	$user_id = get_current_user_id();
	$plan = get_user_meta ($user_id, 'user_plan', true);
	// check if current user has active plan
	if ($plan == 'not paid' or empty($plan)){
		wp_redirect( '/plans', 302 ); 
		exit;
	}
	// Check if user has a basic plan
	// Redirect them to upgrade if trying to view a premium or vip post
	elseif (strpos($plan, 'basic') !== false){
		if (has_category('premium') || has_category('vip')){
			wp_redirect( '/upgrade', 302 ); 
			exit;
		}
	}
	// Check if user has a premium plan
	// Redirect them to upgrade if trying to view a vip post
	elseif (strpos($plan, 'premium') !== false){
		if (has_category('vip')){
			wp_redirect( '/upgrade', 302 ); 
			exit;
		}
	}
}

if ( is_single() and has_category('tips') and !is_user_logged_in()) {
		wp_redirect( '/plans', 302 ); 
		exit;
}

}



//remove comments if user not logged in
// add_action('init', 'remove_comment_support', 100);

// function remove_comment_support() {
//     if (! is_user_logged_in()) {
//         remove_post_type_support( 'post', 'comments' );
//     }
// }

//UPDATE USER PAYMENT DETAILS ON REPAYMENT
add_action( 'template_redirect', 'redirect_from_paid_page' );
function redirect_from_paid_page() {
	$referer = wp_get_referer();
	
	$plan = $_GET['plan'];

if ( is_page('Paid')){
		if ( $referer && $plan ) {
			// UPDATE PLAN
			$user_id = get_current_user_id();
			$currentdate = current_time( 'mysql' );
			update_user_meta( $user_id, 'user_plan', $plan );
			update_user_meta( $user_id, 'payment_date', $currentdate );
			wp_redirect( '/thanks', 301 ); 
  			exit;
    }
}

}



// Block Access to /wp-admin for non admins.
// function custom_blockusers_init() {
//   if ( is_user_logged_in() && is_admin() && !current_user_can( 'administrator' ) ) {
//     wp_redirect( home_url() );
//     exit;
//   }
// }
// add_action( 'init', 'custom_blockusers_init' ); // Hook into 'init'


//Redirect after logout
// add_action( 'wp_logout', 'auto_redirect_external_after_logout');
// function auto_redirect_external_after_logout(){
//   wp_redirect( '/' );
//   exit();
// }


//Login & Logout Links
// add_filter('wp_nav_menu_items', 'add_login_logout_link', 10, 2);
// function add_login_logout_link($items, $args) {
//         ob_start();
//         wp_loginout('index.php');
//         $loginoutlink = ob_get_contents();
//         ob_end_clean();
//         $items .= '<li>'. $loginoutlink .'</li>';
//     return $items;
// }


//Check User Validity After Login

function check_plan_after_login(){
	$user_id = get_current_user();
	global $current_user;
	get_currentuserinfo();
	$plan = get_user_meta($user_id, 'user_plan', true);
	$registration_date = $current_user->user_registered;
	
	if ($plan == 'basiconeweek' || $plan == 'premiumoneweek' || $plan == 'viponeweek'){
		if ((datediff(now(), $registration_date) >7)){
			update_user_meta( $user_id, 'user_plan', 'not paid' );
		}
	}
	
	if ($plan == 'basictwoweeks' || $plan == 'premiumtwoweeks' || $plan == 'viptwoweeks'){
		if ((datediff(now(), $registration_date) >14)){
			update_user_meta( $user_id, 'user_plan', 'not paid' );
		}
	}
	
	if ($plan == 'basiconemonth' || $plan == 'premiumonemonth' || $plan == 'viponemonth'){
		if ((datediff(now(), $registration_date) >30)){
			update_user_meta( $user_id, 'user_plan', 'not paid' );
		}
	}
	
}

add_action('wp_login', 'check_plan_after_login');

