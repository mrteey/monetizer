Plugin Name: Blog Monitization
Plugin URI: http://www.mrteey.com/
Description: Blog Monitization Plug, Allows View of Single Post only by registred users with a plan, works with any payment gateway.
Author: Mr.Teey
Version: 2.1
Author URI: http://www.mrteey.com
License: GPL2