Plugin Name: Monetizer
Plugin URI: http://www.mrteey.com/
Description: Blog Monetization Plug, Allows View of Single Post only by registred users with a plan, works with any payment gateway.
Author: Mr.Teey
Version: 2.6
Author URI: http://www.mrteey.com
License: GPL2


== Description ==
With this plugin you can create multiple payment plans that will allow your blog to protect posts based on them.